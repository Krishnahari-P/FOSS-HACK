package com.example.gracia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
