class StudentModel{
  final String name;
  final String pin;
  StudentModel(this.name,this.pin);
}